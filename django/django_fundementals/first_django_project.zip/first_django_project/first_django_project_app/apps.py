from django.apps import AppConfig


class FirstDjangoProjectAppConfig(AppConfig):
    name = 'first_django_project_app'
